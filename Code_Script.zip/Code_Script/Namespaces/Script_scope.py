def outer_function():
    b = 20
    def inner_func():
        c = 30

a = 10