def printHello():
    print("Hello")     
a = printHello()

# Output: Hello
a