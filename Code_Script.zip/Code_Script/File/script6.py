file = open('newfile.txt', 'r')

print (file.readlines())
