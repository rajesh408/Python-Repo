class MyClass:
	"This is my second class"
	a = 10
	def func(self):
		print('Hello')

# Output: 10
print(MyClass.a)

# Output: <function MyClass.func at -Address in HexDec Value>
print(MyClass.func)

# Output: 'This is my second class'
print(MyClass.__doc__)
