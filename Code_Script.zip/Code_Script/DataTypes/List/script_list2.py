#sclicing elements
my_list = ['p','r','o','g','r','a','m','i','z','z','z']
# elements 3rd to 5th
print(my_list[2:5])

# elements beginning to 4th
print(my_list[:-5])

# elements 6th to end
print(my_list[-5:])

# elements beginning to end
print(my_list[:])
