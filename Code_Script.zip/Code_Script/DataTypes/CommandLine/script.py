"""Echo command line arguments

This program is for
experienced programmers.  
"""

__author__ = "Adarsh (adarsh571@gmail.com)"
__version__ = "$Revision: 1.2 $"
__date__ = "$Date: 2004/05/05 21:57:19 $"
__copyright__ = "Copyright (c) 2016 Adarsh"
__license__ = "Python"

import sys

for arg in sys.argv:
    print (arg)
