#For instance the following output results from running "python demo.py one two 
#three" at the command line:

import sys
print sys.argv