# import only pi from math module

from math import pi
print("The value of pi is", pi)