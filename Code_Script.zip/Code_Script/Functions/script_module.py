# import statement example
# to import standard module math

import math
print("The value of pi is", math.pi)