import random

mood = random.randrange(3)

if mood == 0:
    print (mood)
elif mood == 2:
    print (mood)
else:
    print ("Illegal mood value!.")