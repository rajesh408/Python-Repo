import MySQLdb as mdb

con = mdb.connect(host = "localhost", user = "root", passwd = "", db = "test")


with con:

    cur = con.cursor(mdb.cursors.DictCursor)
    cur.execute("SELECT * FROM Writers LIMIT 4")

    rows = cur.fetchall()

    for row in rows:
        print row["Id"], row["Name"]
		
cur.close
con.close
