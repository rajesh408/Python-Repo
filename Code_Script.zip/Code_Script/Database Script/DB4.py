import MySQLdb as mdb

con = mdb.connect(host = "localhost", user = "root", passwd = "", db = "test")


with con:

    cur = con.cursor()
    cur.execute("SELECT * FROM Writers")

    for i in range(cur.rowcount):
        
        row = cur.fetchone()
        print row[0], row[1]
		
cur.close
con.close
