import MySQLdb as mdb

con = mdb.connect(host = "localhost", user = "root", passwd = "", db = "test")


with con:    

    cur = con.cursor()
        
    cur.execute("UPDATE Writers SET Name = %s WHERE Id = %s", 
        ("Guy de Maupasant", "4"))        
    
    print "Number of rows updated:",  cur.rowcount
		
cur.close
con.close
