import MySQLdb as mdb

con = mdb.connect(host = "localhost", user = "root", passwd = "", db = "test")

with con:
    
    cur = con.cursor()
    cur.execute("DROP TABLE IF EXISTS Writers")
    cur.execute("CREATE TABLE Writers(Id INT PRIMARY KEY AUTO_INCREMENT,\
                Name VARCHAR(25))")
    cur.execute("INSERT INTO Writers(Name) VALUES('Sudha Murthy')")
    cur.execute("INSERT INTO Writers(Name) VALUES('Germillo Stallion')")
    cur.execute("INSERT INTO Writers(Name) VALUES('Robin Sharma')")
    cur.execute("INSERT INTO Writers(Name) VALUES('Deepak Chopra')")
    cur.execute("INSERT INTO Writers(Name) VALUES('Khalid Ansari')")

cur.close()
con.close()
