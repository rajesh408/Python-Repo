# Program to show
# the use of continue
# statement inside loops

for val in "string":
    if val == "i":
        continue
    print(val)

print("The end")